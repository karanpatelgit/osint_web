# OSINT Intelligence Engine — Web Version
### GitHub Pages + GitHub Actions Deploy

Static HTML/JS app — no server, no backend. API keys are injected at build time via GitHub Actions Secrets.

---

## Setup (5 minutes)

### Step 1 — Create a PRIVATE repo on GitHub
> ⚠️ Must be **private** — keys are baked into the built HTML

### Step 2 — Push this code
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/your-repo-name.git
git push -u origin main
```

### Step 3 — Add GitHub Secrets
Go to your repo → **Settings → Secrets and variables → Actions → New repository secret**

Add these secrets (only for providers you use):

| Secret Name | Where to get it |
|---|---|
| `GROQ_API_KEY` | [console.groq.com](https://console.groq.com) — FREE |
| `GEMINI_API_KEY` | [aistudio.google.com](https://aistudio.google.com/app/apikey) — FREE |
| `ANTHROPIC_API_KEY` | [console.anthropic.com](https://console.anthropic.com) |
| `OPENAI_API_KEY` | [platform.openai.com](https://platform.openai.com/api-keys) |

### Step 4 — Enable GitHub Pages
Go to repo → **Settings → Pages**
- Source: **GitHub Actions**
- Save

### Step 5 — Trigger deploy
Push any change to `main`, or go to **Actions → Deploy OSINT Engine → Run workflow**

Your site will be live at: `https://yourusername.github.io/your-repo-name`

---

## How it works

```
GitHub Secrets (keys stored safely)
        ↓
GitHub Actions runs on every push to main
        ↓
sed replaces __GROQ_API_KEY__ placeholders in index.html
        ↓
Built HTML (with keys injected) is deployed to GitHub Pages
        ↓
Browser loads the page, makes API calls directly to AI providers
```

---

## Providers

| Provider | Model | Free? |
|---|---|---|
| Groq | Llama 3.3 70B | ✅ FREE |
| Gemini | 2.0 Flash | ✅ FREE |
| Claude | Sonnet 4 (+ live web search) | Paid |
| OpenAI | GPT-4o | Paid |

---

## Features

- Investigate any entity — company, person, NGO, scheme
- 4 AI providers switchable in UI
- Focus angles: Funding, Network, Contradictions, Legal, Timeline
- Depth modes: Standard, Deep Dive, Financial, Network Map
- Confidence ratings per section
- Clickable source citations
- Quotes bank, SEO headlines, Keywords
- Right-of-reply checklist
- Copy full JSON output

---

## Security Notes

- ✅ Repo is **private** — keys in built HTML are not publicly visible in source
- ✅ GitHub Secrets are never logged or exposed in Actions logs
- ✅ Keys are only injected at build time, not stored anywhere in the repo
- ⚠️ Do NOT make the repo public — the built HTML contains your keys
- ⚠️ Rotate keys immediately if you ever accidentally make the repo public
